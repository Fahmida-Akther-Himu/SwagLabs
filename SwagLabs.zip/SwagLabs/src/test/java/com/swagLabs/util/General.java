package com.swagLabs.util;

public class General {
    final public static int WAIT_TIME = 30;
}
