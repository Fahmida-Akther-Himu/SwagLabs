package com.swagLabs.util;

public class SwagLabs {
    public static final String LOGIN_TITLE = "Swag Labs";
}
